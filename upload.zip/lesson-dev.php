<?php 
$MARKBOOK_GET_API = "https://script.google.com/macros/s/AKfycbylQm3yW95G8C6vmZKwQ88Id_LIPzeSr6heWCEjwlEuESgD9Emy/exec";

if (!isset($_COOKIE['user'])) {
  include('user.php');
  exit();
}

$USER = $_COOKIE['user'];
?>

<!DOCTYPE html>
<html>
<head> 
	<meta charset="UTF-8"> 
  <LINK href="include/lessonstyle.css" title="main" rel="stylesheet" type="text/css">

</head>
<body>
	
	<div id="questionsDiv"></div>
    

    <script src="include/assignment.js"></script>
    <script src="include/acorn.js"></script>
  


<script>

function writeToSheet(scores) {
  
  var data = {
        "action" : "writeToSheet",
        "workbookSheetString" : "<?php echo $_SERVER['QUERY_STRING']?>",
        "user" : "<?php echo $USER ?>",
        "scores" : JSON.stringify(scores)
      };
  var queryString = "?";
  for (var key in data) {
    queryString += key + "=" + encodeURIComponent(data[key]) + "&";
  }
  console.log(queryString);
  fetch("<?php echo $MARKBOOK_GET_API ?>" + queryString, {
    mode: 'no-cors', // no-cors, *cors, same-origin
    method: 'GET', // or 'PUT'
    headers: {
      'Content-Type': 'application/json',
    }
  })
  .then((myJson) => {
    console.log(myJson);
  });

}

function init(markbookSettings) { //this is how it likes to be used. it doesnt like strings for data or arrays for scores

  //internal settings
  var settings = {
      "questionsDiv": document.getElementById("questionsDiv"),
      //no solutions div
      "allowRowDelete" : false,
      "allowRefresh" : false,
      "submitButtonText" : "check answers",
      "showRowTitles" : true,
      "allowGridlines" : false
  };
  
  
  //transfer markbookSettings to settings
  for (var key in markbookSettings) {
    if (markbookSettings.hasOwnProperty(key)) {
      settings[key] = markbookSettings[key];
    }
  }

  /*** CALL CONSTRUCTOR ***/
  window.assignment = new AssignmentHTML(settings);
  
  //markbookupdate
    var markbookUpdateInjector = function(paramaggregateScoreGetter) {
      var aggregateScoreGetter = paramaggregateScoreGetter;
  
      return function(scores) {
        var aggScores = aggregateScoreGetter();
        for (var key in aggScores) {
            scores[key] = aggScores[key];
        }
        writeToSheet(scores);
        console.log(JSON.stringify(scores));
    
      };
  };
    settings.markbookUpdate = markbookUpdateInjector(assignment.aggregateScoreGetter);
            
}
    
</script>
<script src="<?php echo $MARKBOOK_GET_API ?>?action=getMarkbookSettings&workbookSheetString=<?php echo $_SERVER['QUERY_STRING']?>&user=<?php echo urlencode($USER) ?>&prefix=init"></script>


</body>
</html>

