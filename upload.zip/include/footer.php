
<div id=footer>
<div class=widthLimit>
<div class=left>
<p>
    <a href="privacy.php">Privacy</a>
    <br>
    <a href="report-issue.php">Report an Issue</a>
    <br>
    <a href="terms-of-service.php">Terms of service</a>
</p>
</div>
</div>
</div> 