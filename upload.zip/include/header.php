
<div id="topbit"> 
<div class="widthLimit">
    <a href="index.php"><img src="icon128.png" id="logo"/></a>
    <p id="teachometer">Teachometer<br>
    <span id="underTeachometer">A google sheets add-on</span></p>
</div>
<div class="widthLimit">
    <p id="menu"> 
    <a href="get-started.php">Get started</a>
    &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
    <a href="resources.php">Resources</a>
    &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
    <a href="help.php">Help</a>
    </p>
</div>
</div>